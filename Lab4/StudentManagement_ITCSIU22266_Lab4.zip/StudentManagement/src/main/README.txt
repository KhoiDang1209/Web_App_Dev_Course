STUDENT INFORMATION:
Name: Dang Dang Khoi
Student ID: ITCSIU22266
Class: WebAppLab4_Wednesday

COMPLETED EXERCISES:
[x] Exercise 5: Search Functionality
[x] Exercise 6: Validation Enhancement
[x] Exercise 7: Pagination
[ ] Bonus 1: CSV Export
[ ] Bonus 2: Sortable Columns

KNOWN ISSUES:

EXTRA FEATURES:

TIME SPENT: 3 hours

REFERENCES USED:
